package Graph;

import java.util.ArrayList;

public class MyQueue {
    private ArrayList<Integer> arrayList;
    private int head;
    private int tail;
}
